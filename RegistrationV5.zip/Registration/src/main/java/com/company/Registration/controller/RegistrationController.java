package com.company.Registration.controller;

import java.sql.Date;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.company.Registration.dto.UserRequestDto;
import com.company.Registration.responseContract.ResponseContract;
import com.company.Registration.service.RegistrationService;
import com.company.Registration.dto.BookTicketRequestDto;
import com.company.Registration.dto.BookingResponseDto;
import com.company.Registration.dto.FlightResponseDto;
import com.company.Registration.dto.FlightSeatResponseDto;
import com.company.Registration.dto.TicketResponseDto;

import ch.qos.logback.classic.Logger;

@RestController
public class RegistrationController {

	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(RegistrationController.class);

	@Autowired
	RegistrationService registrationService;

	@Autowired
	RestTemplate restTemplate;

	/*
	 * User Registration
	 * 
	 * @Param UserRequestDto
	 * 
	 * @Return ResponseContract with message and Id
	 */
	@PostMapping("/users")
	public ResponseEntity<ResponseContract> registration(@RequestBody UserRequestDto userRequestDto) {
		LOGGER.info("Inside user registration");
		return registrationService.saveUser(userRequestDto);
	}

	/*
	 * User login
	 * 
	 * @Param userId,password
	 * 
	 * @Return message
	 */
	@GetMapping("/users/login")
	public ResponseEntity<String> login(@RequestParam("userId") int userId, @RequestParam("password") String password,
			HttpSession session) {
		LOGGER.info("Inside user login");
		return registrationService.validate(userId, password);
	}

	/*
	 * Searching for flights
	 * 
	 * @Param source,destination,date
	 * 
	 * @Return List of flights
	 */
	@GetMapping("/flights")
	public ResponseEntity<List<FlightResponseDto>> searchFlights(@RequestParam("source") String source,
			@RequestParam("destination") String destination, @RequestParam("date") Date date) {
		LOGGER.info("Inside flight search");
		String searchFlightsUrl = "http://FlightSearch/flights?source=" + source + "&destination=" + destination
				+ "&date=" + date;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List<FlightResponseDto>> searchFlights = new HttpEntity<List<FlightResponseDto>>(headers);
		ResponseEntity<List<FlightResponseDto>> response = restTemplate.exchange(searchFlightsUrl, HttpMethod.GET,
				searchFlights, new ParameterizedTypeReference<List<FlightResponseDto>>() {
				});
		return new ResponseEntity<List<FlightResponseDto>>(response.getBody(), HttpStatus.OK);
	}

	/*
	 * Searching for flights with given cost
	 * 
	 * @Param cost
	 * 
	 * @Return List of flights
	 */
	@GetMapping("/flights/cost")
	public ResponseEntity<List<FlightResponseDto>> filterFlightsByCost(@RequestParam("cost") double cost) {
		LOGGER.info("Inside filter flights by cost");
		String searchFlightsUrl = "http://FlightSearch/flights/cost?cost=" + cost;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List<FlightResponseDto>> searchFlights = new HttpEntity<List<FlightResponseDto>>(headers);
		ResponseEntity<List<FlightResponseDto>> response = restTemplate.exchange(searchFlightsUrl, HttpMethod.GET,
				searchFlights, new ParameterizedTypeReference<List<FlightResponseDto>>() {
				});
		return new ResponseEntity<List<FlightResponseDto>>(response.getBody(), HttpStatus.OK);
	}

	/*
	 * Searching for flights with given name
	 * 
	 * @Param name
	 * 
	 * @Return List of flights
	 */
	@GetMapping("/flights/name")
	public ResponseEntity<List<FlightResponseDto>> filterFlightsByName(@RequestParam("name") String name) {
		LOGGER.info("Inside filter flights by name");
		String searchFlightsUrl = "http://FlightSearch/flights/name?name=" + name;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List<FlightResponseDto>> searchFlights = new HttpEntity<List<FlightResponseDto>>(headers);
		ResponseEntity<List<FlightResponseDto>> response = restTemplate.exchange(searchFlightsUrl, HttpMethod.GET,
				searchFlights, new ParameterizedTypeReference<List<FlightResponseDto>>() {
				});
		return new ResponseEntity<List<FlightResponseDto>>(response.getBody(), HttpStatus.OK);
	}

	/*
	 * Checking for availability of seats
	 * 
	 * @Param flightId
	 * 
	 * @Returns Number of seats
	 */
	@GetMapping("/flights/{flightId}/seats")
	public ResponseEntity<FlightSeatResponseDto> checkAvailability(@PathVariable("flightId") int flightId) {
		LOGGER.info("Checking for availibility of seats for given flight");
		String availibilityUrl = "http://FlightSearch/flights/" + flightId + "/seats";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<FlightSeatResponseDto> searchFlights = new HttpEntity<FlightSeatResponseDto>(headers);
		ResponseEntity<FlightSeatResponseDto> response = restTemplate.exchange(availibilityUrl, HttpMethod.GET,
				searchFlights, FlightSeatResponseDto.class);
		return new ResponseEntity<FlightSeatResponseDto>(response.getBody(), HttpStatus.OK);
	}

	/*
	 * Booking ticket
	 * 
	 * @Param BookTicketRequestDto
	 * 
	 * @Return TicketId with message
	 */
	@PostMapping("/tickets")
	public ResponseEntity<BookingResponseDto> bookTicket(@RequestBody BookTicketRequestDto bookTicketRequestDto) {
		LOGGER.info("Inside ticket booking");
		String bookUrl = "http://FlightTicket/tickets";
		ResponseEntity<BookingResponseDto> response = restTemplate.postForEntity(bookUrl, bookTicketRequestDto,
				BookingResponseDto.class);
		return new ResponseEntity<BookingResponseDto>(response.getBody(), HttpStatus.OK);
	}

	/*
	 * Getting ticket details
	 * 
	 * @Param TicketId
	 * 
	 * @Return TicketResponseDto with ticket details
	 */
	@GetMapping("/tickets/{ticketId}")
	public ResponseEntity<TicketResponseDto> getTicket(@PathVariable("ticketId") int ticketId) {
		LOGGER.info("Getting ticket details");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String ticketUrl = "http://FlightTicket/tickets/" + ticketId;
		HttpEntity<TicketResponseDto> ticketEntity = new HttpEntity<TicketResponseDto>(headers);
		ResponseEntity<TicketResponseDto> response = restTemplate.exchange(ticketUrl, HttpMethod.GET, ticketEntity,
				TicketResponseDto.class);
		return new ResponseEntity<TicketResponseDto>(response.getBody(), HttpStatus.OK);
	}

	/*
	 * Cancelling ticket
	 * 
	 * @Param TicketId
	 * 
	 * @Return TicketId with message
	 */
	@DeleteMapping("/tickets/{ticketId}")
	public ResponseEntity<BookingResponseDto> cancelTicket(@PathVariable("ticketId") int ticketId) {
		LOGGER.info("Cancelling ticket details");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String ticketUrl = "http://FlightTicket/tickets/" + ticketId;
		HttpEntity<BookingResponseDto> ticketEntity = new HttpEntity<BookingResponseDto>(headers);
		ResponseEntity<BookingResponseDto> response = restTemplate.exchange(ticketUrl, HttpMethod.DELETE, ticketEntity,
				BookingResponseDto.class);
		return new ResponseEntity<BookingResponseDto>(response.getBody(), HttpStatus.OK);
	}
}
