package com.company.Registration.service;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.company.Registration.dao.UserRepository;
import com.company.Registration.dto.UserRequestDto;
import com.company.Registration.exceptionHandling.InvalidCredentialsException;
import com.company.Registration.model.User;
import com.company.Registration.responseContract.ResponseContract;

@Service
public class RegistrationServiceImpl implements RegistrationService {
	@Autowired
	UserRepository userRepository;

	@Autowired
	ModelMapper modelMapper;

	static int id = 1001;

	/* User registration method */
	@Override
	public ResponseEntity<ResponseContract> saveUser(UserRequestDto userRequestDto) {
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		User user = modelMapper.map(userRequestDto, User.class);
		user.setUserId(id++);
		userRepository.save(user);
		ResponseContract response = new ResponseContract("Successfully registered", user.getUserId());
		return new ResponseEntity<ResponseContract>(response, HttpStatus.OK);
	}

	/* User login and validation */
	@Override
	public ResponseEntity<String> validate(int userId, String password) {
		User user = userRepository.findUserByUserIdAndPassword(userId, password);
		if (user == null) {
			throw new InvalidCredentialsException("Invalid login");
		}
		return new ResponseEntity<String>("Successfully logged in", HttpStatus.OK);
	}
}
