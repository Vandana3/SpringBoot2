package com.company.Registration.dto;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class BookTicketRequestDto {
	Integer flightId;
	int numberOfTickets;
	String category;
	int userId;
	Date date;
	String mailId;
    List<PassengerDetails> passenger;
    
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public List<PassengerDetails> getPassenger() {
		return passenger;
	}
	public void setPassenger(List<PassengerDetails> passenger) {
		this.passenger = passenger;
	}
	public Integer getFlightId() {
		return flightId;
	}
	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}
	public int getNumberOfTickets() {
		return numberOfTickets;
	}
	public void setNumberOfTickets(int numberOfTickets) {
		this.numberOfTickets = numberOfTickets;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
	
}
