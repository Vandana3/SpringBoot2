package com.company.Registration.responseContract;

public class ResponseData {
	 public String message;
		
	 public int id;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	 
}
