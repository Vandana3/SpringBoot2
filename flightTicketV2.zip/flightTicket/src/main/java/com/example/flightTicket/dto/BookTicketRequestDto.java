package com.example.flightTicket.dto;

import java.sql.Date;
import java.util.HashMap;

import org.springframework.stereotype.Component;

import com.example.flightTicket.model.Passenger;
@Component
public class BookTicketRequestDto {
	Integer flightId;
	int numberOfTickets;
	String category;
	int userId;
	String source;
	String destination;
	Date date;
    
    HashMap<String,Integer> passenger;
	
	
	public HashMap<String, Integer> getPassenger() {
		return passenger;
	}
	public void setPassenger(HashMap<String, Integer> passenger) {
		this.passenger = passenger;
	}
	public Integer getFlightId() {
		return flightId;
	}
	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}
	public int getNumberOfTickets() {
		return numberOfTickets;
	}
	public void setNumberOfTickets(int numberOfTickets) {
		this.numberOfTickets = numberOfTickets;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
	
}
