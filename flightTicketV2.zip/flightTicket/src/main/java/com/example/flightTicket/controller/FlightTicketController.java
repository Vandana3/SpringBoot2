package com.example.flightTicket.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.service.FlightTicketService;

@RestController
public class FlightTicketController {
@Autowired
FlightTicketService flightTicketService;
	
@PostMapping("/book")
public ResponseEntity<Object> bookTicket(@RequestBody  BookTicketRequestDto bookTicketRequestDto){
	return flightTicketService.bookTicket(bookTicketRequestDto);
	
}
}
