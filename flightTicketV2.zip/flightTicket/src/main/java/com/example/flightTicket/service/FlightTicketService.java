package com.example.flightTicket.service;

import org.springframework.http.ResponseEntity;

import com.example.flightTicket.dto.BookTicketRequestDto;

public interface FlightTicketService {

	ResponseEntity<Object> bookTicket(BookTicketRequestDto bookTicketRequestDto);

}
