package com.example.flightTicket.model;

import java.sql.Date;
import java.sql.Time;



public class Flight {

private Integer flightId;
private String name;
private String source;
private String destination;
private Date date;
private Time arrivalTime;
private Time departureTime;
private String type;
public Integer getFlightId() {
	return flightId;
}
public void setFlightId(Integer flightId) {
	this.flightId = flightId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getDestination() {
	return destination;
}
public void setDestination(String destination) {
	this.destination = destination;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public Time getArrivalTime() {
	return arrivalTime;
}
public void setArrivalTime(Time arrivalTime) {
	this.arrivalTime = arrivalTime;
}
public Time getDepartureTime() {
	return departureTime;
}
public void setDepartureTime(Time departureTime) {
	this.departureTime = departureTime;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}

}
