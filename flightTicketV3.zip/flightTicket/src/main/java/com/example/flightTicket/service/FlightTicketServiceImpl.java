package com.example.flightTicket.service;

import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.flightTicket.responseContract.ResponseContract;
import com.example.flightTicket.dao.PassengerRepository;
import com.example.flightTicket.dao.TicketRepository;
import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.dto.FlightResponseDto;
import com.example.flightTicket.dto.FlightSeatResponseDto;
import com.example.flightTicket.dto.LoginResponseDto;
import com.example.flightTicket.dto.TicketResponseEntity;
import com.example.flightTicket.exceptionHandling.ImproperCategoryException;
import com.example.flightTicket.exceptionHandling.InvalidLoginException;
import com.example.flightTicket.exceptionHandling.NoFlightsFoundException;
import com.example.flightTicket.exceptionHandling.NoSeatsAvailableException;
import com.example.flightTicket.exceptionHandling.PassengerDetailsRequiredException;
import com.example.flightTicket.exceptionHandling.TicketNotFoundException;
import com.example.flightTicket.model.CompositeId;
import com.example.flightTicket.model.Passenger;
import com.example.flightTicket.model.Ticket;

@Service
public class FlightTicketServiceImpl implements FlightTicketService {
	static int pId = 4000;
	static int tId = 5000;
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	PassengerRepository passengerRepository;

	@Autowired
	TicketRepository ticketRepository;

	/* Book ticket after appropriate validations */
	@Override
	public ResponseEntity<Object> bookTicket(BookTicketRequestDto bookTicketRequestDto) {

		String userUrl = "http://localhost:8083/user/login?name=vandana&password=v123";
		LoginResponseDto loginResponseDto = restTemplate.getForObject(userUrl, LoginResponseDto.class);
		if (loginResponseDto.getId() != bookTicketRequestDto.getUserId()) {
			throw new InvalidLoginException("Invalid userId");
		}
		
		
		/* Checking if flights exist with given source destination and date */
		String flightUrl = "http://localhost:8084/flights";
		UriComponentsBuilder flightbuilder = UriComponentsBuilder.fromUriString(flightUrl)
				.queryParam("source", bookTicketRequestDto.getSource())
				.queryParam("destination", bookTicketRequestDto.getDestination())
				.queryParam("date", bookTicketRequestDto.getDate());
		List<HashMap> flightList = new ArrayList<HashMap>();
		flightList = restTemplate.getForObject(flightbuilder.toUriString(), ArrayList.class);
		if (flightList.isEmpty())
			throw new NoFlightsFoundException("No flight for your requirement");

		/*
		 * Checking if entered flight id is matching with existing flight id with given
		 * source destination and time
		 */
		List<HashMap> newflightList = flightList.stream()
				.filter(f -> (int) f.get("flightId") == (int) bookTicketRequestDto.getFlightId())
				.collect(Collectors.toList());
		if (newflightList.isEmpty()) {
			throw new NoFlightsFoundException("FlightId not matching");
		}

		/*
		 * Checking for availibility of seats and booking tickets only if seats are
		 * available.
		 */
		Boolean bool = false;
		String seatsUrl = "http://localhost:8084/flights/{flightId}/seats";
		int urlParam = bookTicketRequestDto.getFlightId();
		UriComponentsBuilder seatbuilder = UriComponentsBuilder.fromUriString(seatsUrl);
		FlightSeatResponseDto flightSeatResponseDto = restTemplate
				.getForObject(seatbuilder.buildAndExpand(urlParam).toUri(), FlightSeatResponseDto.class);
		switch (bookTicketRequestDto.getCategory()) {
		case "business":
			if (flightSeatResponseDto.getBusinessSeats() - bookTicketRequestDto.getNumberOfTickets() >= 0)
				bool = true;
			break;
		case "economy":
			if (flightSeatResponseDto.getEconomySeats() - bookTicketRequestDto.getNumberOfTickets() >= 0)
				bool = true;
			break;
		default:
			throw new ImproperCategoryException("Give proper category");
		}
		if (bool == false)
			throw new NoSeatsAvailableException("No seats available");

		if (bookTicketRequestDto.getPassenger().size() != bookTicketRequestDto.getNumberOfTickets()) {
			throw new PassengerDetailsRequiredException("Enter all passenger details");
		}

		/* Getting airport name to print in ticket */
		String airportUrl = "http://localhost:8084/airport/name";
		UriComponentsBuilder airportbuilder = UriComponentsBuilder.fromUriString(airportUrl).queryParam("location",
				bookTicketRequestDto.getSource());
		String airportName = restTemplate.getForObject(airportbuilder.toUriString(), String.class);

		/* Setting ticket details. */
		Ticket ticket = new Ticket();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		ticket = modelMapper.map(bookTicketRequestDto, Ticket.class);
		int ticketId = tId++;
		ticket.setTicketId(ticketId);
		ticket.setAirportName(airportName);
		ticket.setArrivalTime(Time.valueOf((String) newflightList.get(0).get("arrivalTime")));
		ticket.setDepartureTime(Time.valueOf((String) newflightList.get(0).get("departureTime")));
		switch (bookTicketRequestDto.getCategory()) {
		case "business":
			ticket.setCost(
					bookTicketRequestDto.getNumberOfTickets() * (double) newflightList.get(0).get("businessCost"));
			break;
		case "economy":
			ticket.setCost(
					bookTicketRequestDto.getNumberOfTickets() * (double) newflightList.get(0).get("economyCost"));
			break;
		}
		ticketRepository.save(ticket);

		/* Setting passenger details */
		HashMap passengers = bookTicketRequestDto.getPassenger();
		Iterator hmIterator = passengers.entrySet().iterator();
		while (hmIterator.hasNext()) {
			CompositeId compositeId = new CompositeId();
			compositeId.setTicketId(ticketId);
			compositeId.setPassengerId(pId++);
			Passenger passenger = new Passenger();
			Map.Entry mapElement = (Map.Entry) hmIterator.next();
			passenger.setAge((int) mapElement.getValue());
			passenger.setName((String) mapElement.getKey());
			passenger.setCompositeId(compositeId);
			passengerRepository.save(passenger);
		}

		/* Updating seat in database after ticket booking */
		String updateSeatUrl = "http://localhost:8084/flights/category/seats";
		UriComponentsBuilder updateSeatBuilder = UriComponentsBuilder.fromUriString(updateSeatUrl)
				.queryParam("flightId", bookTicketRequestDto.getFlightId())
				.queryParam("category", bookTicketRequestDto.getCategory())
				.queryParam("numberOfTickets", bookTicketRequestDto.getNumberOfTickets());
		int seats = restTemplate.getForObject(updateSeatBuilder.toUriString(), Integer.class);

		/* Setting ticket response contract */
		HttpStatus status;
		status = HttpStatus.OK;
		ResponseContract response = new ResponseContract("Ticket successfully booked", status.value(),
				ticket.getTicketId());
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	/* Getting ticket details by passing ticketid */
	@Override
	public List<TicketResponseEntity> getTicket(int ticketId) {
		List<TicketResponseEntity> ticketList = new ArrayList<TicketResponseEntity>();
		Optional<Ticket> optionalTicket = ticketRepository.findById(ticketId);
		if (!optionalTicket.isPresent())
			throw new TicketNotFoundException("Improper ticket Id");
		Ticket ticket = optionalTicket.get();
		TicketResponseEntity ticketResponseEntity = modelMapper.map(ticket, TicketResponseEntity.class);
		ticketList.add(ticketResponseEntity);
		return ticketList;

	}

	/* Cancel ticket */
	@Override
	public ResponseEntity<Object> cancelTicket(int ticketId) {
		Optional<Ticket> optionalTicket = ticketRepository.findById(ticketId);
		if (!optionalTicket.isPresent())
			throw new TicketNotFoundException("Improper ticket Id");
		Ticket ticket = optionalTicket.get();
		String addSeatUrl = "http://localhost:8084/flights/category/seats/cancel";
		UriComponentsBuilder addSeatBuilder = UriComponentsBuilder.fromUriString(addSeatUrl)
				.queryParam("flightId", ticket.getFlightId()).queryParam("category", ticket.getCategory())
				.queryParam("numberOfTickets", ticket.getNumberOfTickets());
		int seats = restTemplate.getForObject(addSeatBuilder.toUriString(), Integer.class);
		passengerRepository.deletePassengersById(ticketId);
		ticketRepository.deleteById(ticketId);

		HttpStatus status;
		status = HttpStatus.OK;
		ResponseContract response = new ResponseContract("Ticket successfully canceled", status.value(),
				ticket.getTicketId());
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

}
