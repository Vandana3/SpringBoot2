package com.example.flightTicket.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.dto.TicketResponseEntity;

public interface FlightTicketService {

	ResponseEntity<Object> bookTicket(BookTicketRequestDto bookTicketRequestDto);

	List<TicketResponseEntity> getTicket(int ticketId);

	ResponseEntity<Object> cancelTicket(int ticketId);

}
