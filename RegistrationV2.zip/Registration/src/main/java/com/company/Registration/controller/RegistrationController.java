package com.company.Registration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.Registration.dto.UserRequestDto;
import com.company.Registration.model.User;
import com.company.Registration.service.RegistrationService;

@RestController
public class RegistrationController {
	@Autowired
	RegistrationService registrationService;
@PostMapping("/user")
public ResponseEntity<Object> saveUser(@RequestBody UserRequestDto userRequestDto) {
	
	return registrationService.saveUser(userRequestDto);
	 
}

@GetMapping("/user/login")
public ResponseEntity<Object> login(@RequestParam("name")String name,@RequestParam("password")String password)
{
	
	return registrationService.validate(name,password);
}	



}
