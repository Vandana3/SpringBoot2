package com.company.flightSearch.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
 
@ResponseStatus(HttpStatus.NOT_FOUND)
public class NoAirportFoundException extends RuntimeException {
	 public NoAirportFoundException(String exception) {
	        super(exception);
	    }
}