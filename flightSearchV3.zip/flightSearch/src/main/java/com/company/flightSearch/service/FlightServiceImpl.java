package com.company.flightSearch.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.flightSearch.dao.AirportRepository;
import com.company.flightSearch.dao.CategoryRepository;
import com.company.flightSearch.dao.FlightRepository;
import com.company.flightSearch.dto.FlightResponseDto;
import com.company.flightSearch.dto.FlightSeatResponseDto;
import com.company.flightSearch.exceptionHandling.NoAirportFoundException;
import com.company.flightSearch.exceptionHandling.NoFlightsFoundException;
import com.company.flightSearch.model.Airport;
import com.company.flightSearch.model.Category;
import com.company.flightSearch.model.Flight;


import ch.qos.logback.classic.Logger;

@Service
public class FlightServiceImpl implements FlightService {
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(FlightServiceImpl.class);

	@Autowired
	FlightRepository flightRepository;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	AirportRepository airportRepository;

	@Autowired
	ModelMapper modelMapper;

	List<FlightResponseDto> flightList = new ArrayList<FlightResponseDto>();

	/* Searching for flights with given source, destination and date */
	@Override
	public List<FlightResponseDto> searchFlights(String source, String destination, Date date) {
		flightList.clear();
		Category category = new Category();
		FlightResponseDto flightResponseDto = new FlightResponseDto();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		LOGGER.info("Before");
		Iterable<Flight> flightIterable = flightRepository.findFlightBySourceAndDestinationAndDate(source, destination,
				date);
		LOGGER.info("After");
		if (!flightIterable.iterator().hasNext()) {
			throw new NoFlightsFoundException("No flights available");
		}
		for (Flight flight : flightIterable) {
			java.util.Optional<Category> optionalCategory = categoryRepository.findById(flight.getFlightId());
			category = optionalCategory.get();
			flightResponseDto = modelMapper.map(flight, FlightResponseDto.class);
			flightResponseDto.setBusinessCost(category.getBusinessCost());
			flightResponseDto.setBusinessSeats(category.getBusinessSeats());
			flightResponseDto.setEconomyCost(category.getEconomyCost());
			flightResponseDto.setEconomySeats(category.getEconomySeats());
			flightList.add(flightResponseDto);
		}
		LOGGER.info("End");
		return flightList;
	}

	/* Filter flights by flight name */
	@Override
	public List<FlightResponseDto> filterFlightsByName(String name) {
		if (flightList.isEmpty()) {
			throw new NoFlightsFoundException("Please provide source and destination");
		}
		List<FlightResponseDto> newFlightList = flightList.stream().filter(f -> f.getName().equals(name))
				.collect(Collectors.toList());
		if (newFlightList.isEmpty()) {
			throw new NoFlightsFoundException("No flights with given name available");
		}
		return newFlightList;
	}

	/* Filter flights by cost */
	@Override
	public List<FlightResponseDto> filterFlightsByCost(double cost) {
		if (flightList.isEmpty()) {
			throw new NoFlightsFoundException("Please provide source and destination");
		}
		List<FlightResponseDto> newFlightList = flightList.stream()
				.filter(f -> f.getBusinessCost() <= cost || f.getEconomyCost() <= cost).collect(Collectors.toList());
		if (newFlightList.isEmpty()) {
			throw new NoFlightsFoundException("No flights available for given cost");
		}
		return newFlightList;
	}

	/* Check for availibility of seats for given flight */
	@Override
	public FlightSeatResponseDto checkAvailability(int flightId) {
		FlightSeatResponseDto flightSeatResponseDto = new FlightSeatResponseDto();
		Category category = new Category();
		java.util.Optional<Category> optionalCategory = categoryRepository.findById(flightId);
		if (!optionalCategory.isPresent()) {
			throw new NoFlightsFoundException("No flight with given id available");
		}
		category = optionalCategory.get();
		flightSeatResponseDto.setEconomySeats(category.getEconomySeats());
		flightSeatResponseDto.setBusinessSeats(category.getBusinessSeats());
		return flightSeatResponseDto;
	}

	/* Getting name of the airport */
	@Override
	public String getAirportName(String location) {
		Airport airport = airportRepository.findNameByLocation(location);
		if (airport.getName() == null)
			throw new NoAirportFoundException("No airport at given location");
		return airport.getName();
	}

	/* Updating seats after ticket booking */
	@Override
	public int updateSeatsAfterBooking(int flightId, String category, int numberOfTickets) {
		if (category.equals("economy")) {
			return categoryRepository.deleteEconomySeats(flightId, numberOfTickets);
		}
		if (category.equals("business")) {
			return categoryRepository.deleteBusinessSeats(flightId, numberOfTickets);
		}
		return 0;
	}
	
	@Override
	public int updateSeatsAfterCancelling(int flightId, String category, int numberOfTickets) {
		if (category.equals("economy")) {
			return categoryRepository.addEconomySeats(flightId, numberOfTickets);
		}
		if (category.equals("business")) {
			return categoryRepository.addBusinessSeats(flightId, numberOfTickets);
		}
		return 0;
	}

}
