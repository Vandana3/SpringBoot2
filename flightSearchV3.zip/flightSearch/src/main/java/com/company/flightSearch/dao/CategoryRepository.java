package com.company.flightSearch.dao;

import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.flightSearch.model.Category;

@Repository
public interface CategoryRepository extends CrudRepository<Category,Integer>{
	@Transactional
	 @Modifying(clearAutomatically = true)
	 @Query("Update Category set economySeats=economySeats-:numberOfTickets where flightId=:flightId")
	public int deleteEconomySeats(@PathParam("flightId")int flightId, @PathParam("numberOfTickets")int numberOfTickets);

	@Transactional
	 @Modifying(clearAutomatically = true)
	 @Query("Update Category set businessSeats=businessSeats-:numberOfTickets where flightId=:flightId")
	public int deleteBusinessSeats(@PathParam("flightId")int flightId, @PathParam("numberOfTickets")int numberOfTickets);

	@Transactional
	 @Modifying(clearAutomatically = true)
	 @Query("Update Category set economySeats=economySeats+:numberOfTickets where flightId=:flightId")
	public int addEconomySeats(@PathParam("flightId")int flightId, @PathParam("numberOfTickets")int numberOfTickets);

	@Transactional
	 @Modifying(clearAutomatically = true)
	 @Query("Update Category set businessSeats=businessSeats+:numberOfTickets where flightId=:flightId")
	public int addBusinessSeats(@PathParam("flightId")int flightId, @PathParam("numberOfTickets")int numberOfTickets);


}
