package com.company.flightSearch.service;

import java.sql.Date;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.company.flightSearch.dto.FlightResponseDto;
import com.company.flightSearch.dto.FlightSeatResponseDto;
import com.company.flightSearch.model.Flight;

public interface FlightService {

	ResponseEntity<List<FlightResponseDto>>   searchFlights(String source, String destination, Date date);

	ResponseEntity<List<FlightResponseDto>> filterFlightsByName( String name);

	ResponseEntity<List<FlightResponseDto>> filterFlightsByCost(double cost);

	ResponseEntity<FlightSeatResponseDto> checkAvailability(int flightId);

	ResponseEntity<String>getAirportName(String location);

	ResponseEntity<Integer>  updateSeatsAfterBooking(int flightId, String category, int numberOfTickets);

	ResponseEntity<Integer>  updateSeatsAfterCancelling(int flightId, String category, int numberOfTickets);

	ResponseEntity<FlightResponseDto> getFlightDetails(Integer flightId);

}
