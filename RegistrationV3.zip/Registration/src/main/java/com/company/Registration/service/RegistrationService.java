package com.company.Registration.service;

import org.springframework.http.ResponseEntity;

import com.company.Registration.dto.UserRequestDto;
import com.company.Registration.model.User;
import com.company.Registration.responseContract.LoginResponseDto;
import com.company.Registration.responseContract.ResponseContract;

public interface RegistrationService {

	ResponseEntity<Object> saveUser(UserRequestDto userRequestDto);

	LoginResponseDto validate(String name, String password);

	
}
