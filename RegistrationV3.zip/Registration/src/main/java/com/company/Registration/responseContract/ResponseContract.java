package com.company.Registration.responseContract;



import javax.xml.bind.annotation.XmlRootElement;
 
@XmlRootElement(name = "error")
public class ResponseContract 
{
	 public String message;
	 public int status;
	 public int id;
     public ResponseContract(String message,int status, int id) {
        
        this.message = message;
        this.status=status;
        this.id = id;
    }
	

}
