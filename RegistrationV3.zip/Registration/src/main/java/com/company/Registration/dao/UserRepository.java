package com.company.Registration.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.Registration.model.User;

@Repository
public interface UserRepository extends CrudRepository<User,Integer>{

	User findUserByNameAndPassword(String name, String password);

}
