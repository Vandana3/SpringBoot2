package com.company.Registration.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.company.Registration.dto.UserRequestDto;
import com.company.Registration.model.User;
import com.company.Registration.responseContract.LoginResponseDto;
import com.company.Registration.service.RegistrationService;

import ch.qos.logback.classic.Logger;

@RestController
public class RegistrationController {

	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(RegistrationController.class);

	@Autowired
	RegistrationService registrationService;

	@PostMapping("/users")
	public ResponseEntity<Object> registration(@RequestBody UserRequestDto userRequestDto) {
		LOGGER.info("Inside user registration");
		return registrationService.saveUser(userRequestDto);
	}

	@GetMapping("/user/login")
	public LoginResponseDto login(@RequestParam("name") String name, @RequestParam("password") String password,HttpSession session) {
		LOGGER.info("Inside user login");
		LoginResponseDto response=registrationService.validate(name, password);
		session.setAttribute("userId", response.getId());
		return response;
	}

}
