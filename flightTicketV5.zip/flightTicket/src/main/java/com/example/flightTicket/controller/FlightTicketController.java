package com.example.flightTicket.controller;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.dto.BookingResponseDto;
import com.example.flightTicket.dto.TicketResponseDto;
import com.example.flightTicket.service.FlightTicketService;

import ch.qos.logback.classic.Logger;

@RestController
public class FlightTicketController {
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(FlightTicketController.class);

	@Autowired
	FlightTicketService flightTicketService;

	/*
	 * Booking ticket
	 * 
	 * @Param BookTicketRequestDto
	 * 
	 * @Return TicketId with message
	 */
	@PostMapping("/tickets")
	public ResponseEntity<BookingResponseDto> bookTicket(@RequestBody BookTicketRequestDto bookTicketRequestDto) {
		LOGGER.info("Inside ticket booking");
		return flightTicketService.bookTicket(bookTicketRequestDto);
	}

	/*
	 * Getting ticket details
	 * 
	 * @Param TicketId
	 * 
	 * @Return TicketResponseDto with ticket details
	 */
	@GetMapping("/tickets/{ticketId}")
	public ResponseEntity<TicketResponseDto> getTicket(@PathVariable("ticketId") int ticketId) {
		LOGGER.info("Getting ticket details");
		return flightTicketService.getTicket(ticketId);
	}

	/*
	 * Cancelling ticket
	 * 
	 * @Param TicketId
	 * 
	 * @Return TicketId with message
	 */
	@DeleteMapping("/tickets/{ticketId}")
	public ResponseEntity<BookingResponseDto> cancelTicket(@PathVariable("ticketId") int ticketId) {
		LOGGER.info("Getting ticket cancelling");
		return flightTicketService.cancelTicket(ticketId);
	}
}
