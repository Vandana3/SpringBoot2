package com.example.flightTicket.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.dto.BookingResponseDto;
import com.example.flightTicket.dto.TicketResponseDto;
import com.example.flightTicket.responseContract.ResponseContract;

public interface FlightTicketService {

	ResponseEntity<BookingResponseDto> bookTicket(BookTicketRequestDto bookTicketRequestDto);

	ResponseEntity<TicketResponseDto>getTicket(int ticketId);

	 ResponseEntity<BookingResponseDto>  cancelTicket(int ticketId);

}
