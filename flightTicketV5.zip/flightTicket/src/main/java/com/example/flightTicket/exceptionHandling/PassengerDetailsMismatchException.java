package com.example.flightTicket.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
 
@ResponseStatus(HttpStatus.NOT_FOUND)
public class PassengerDetailsMismatchException extends RuntimeException {
	 public PassengerDetailsMismatchException(String exception) {
	        super(exception);
	    }
}
