package com.example.flightTicket.dao;

import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.flightTicket.model.CompositeId;
import com.example.flightTicket.model.Passenger;

@Repository
public interface PassengerRepository extends CrudRepository<Passenger,CompositeId>{
@Transactional
@Modifying(clearAutomatically=true)
@Query(value="delete from passenger where ticket_id=:ticketId",nativeQuery=true)
public void deletePassengersById(@PathParam("ticketId")int ticketId);
}
