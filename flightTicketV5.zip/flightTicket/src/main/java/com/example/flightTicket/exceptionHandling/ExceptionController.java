package com.example.flightTicket.exceptionHandling;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;



@ControllerAdvice
public class ExceptionController {
  
   @ExceptionHandler(value=FlightNotFoundException.class)
   public ResponseEntity<ErrorResponse> exception(FlightNotFoundException exception) {
	   HttpStatus status;
	   status=HttpStatus.NOT_FOUND;
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message,status.value(), LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   
   @ExceptionHandler(value=CategoryNotFoundException.class)
   public ResponseEntity<ErrorResponse> exception(CategoryNotFoundException exception) {
	   HttpStatus status;
	   status=HttpStatus.NOT_FOUND;
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message,status.value(), LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   @ExceptionHandler(value=SeatNotAvailableException.class)
   public ResponseEntity<ErrorResponse> exception(SeatNotAvailableException exception) {
	   HttpStatus status;
	   status=HttpStatus.NOT_FOUND;
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message,status.value(), LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   @ExceptionHandler(value=PassengerDetailsMismatchException.class)
   public ResponseEntity<ErrorResponse> exception(PassengerDetailsMismatchException exception) {
	   HttpStatus status;
	   status=HttpStatus.NOT_FOUND;
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message,status.value(), LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   @ExceptionHandler(value=TicketNotFoundException.class)
   public ResponseEntity<ErrorResponse> exception(TicketNotFoundException exception) {
	   HttpStatus status;
	   status=HttpStatus.NOT_FOUND;
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message,status.value(), LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   @ExceptionHandler(value=InvalidCredentialsException.class)
   public ResponseEntity<ErrorResponse> exception(InvalidCredentialsException exception) {
	   HttpStatus status;
	   status=HttpStatus.NOT_FOUND;
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message,status.value(), LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
  
}
