package com.company.flightSearch.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Airport {
	@Id
private Integer airportId;
private String name;
private String location;
public Integer getAirportId() {
	return airportId;
}
public void setAirportId(Integer airportId) {
	this.airportId = airportId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}

}
