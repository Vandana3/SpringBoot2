package com.company.flightSearch.service;

import java.util.ArrayList;
import java.util.List;

import com.company.flightSearch.dto.FlightResponseDto;

public class FlightList {
	private List<FlightResponseDto> flights;
	 
    public FlightList() {
        flights = new ArrayList<>();
    }

	public List<FlightResponseDto> getFlights() {
		return flights;
	}

	public void setFlights(List<FlightResponseDto> flights) {
		this.flights = flights;
	}
    
}
