package com.example.flightTicket.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.dto.TicketResponseDto;
import com.example.flightTicket.responseContract.ResponseContract;
import com.example.flightTicket.service.FlightTicketService;

import ch.qos.logback.classic.Logger;

@RestController
public class FlightTicketController {
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(FlightTicketController.class);

	@Autowired
	FlightTicketService flightTicketService;

	@PostMapping("/book")
	public ResponseEntity<ResponseContract> bookTicket(@RequestBody BookTicketRequestDto bookTicketRequestDto) {
		LOGGER.info("Inside ticket booking");
		return flightTicketService.bookTicket(bookTicketRequestDto);
	}

	@GetMapping("/ticket/{ticketId}")
	public ResponseEntity<TicketResponseDto> getTicket(@PathVariable("ticketId") int ticketId) {
		LOGGER.info("Getting ticket details");
		return flightTicketService.getTicket(ticketId);
	}
	
	@DeleteMapping("/ticket/{ticketId}/cancel")
	public ResponseEntity<ResponseContract>  cancelTicket(@PathVariable("ticketId")int ticketId) {
	return flightTicketService.cancelTicket(ticketId);
	}
	
}
