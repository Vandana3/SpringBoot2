package com.example.flightTicket.service;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.flightTicket.responseContract.ResponseContract;
import com.example.flightTicket.dao.PassengerRepository;
import com.example.flightTicket.dao.TicketRepository;
import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.dto.FlightResponseDto;
import com.example.flightTicket.dto.FlightSeatResponseDto;
import com.example.flightTicket.dto.LoginResponseDto;
import com.example.flightTicket.dto.PassengerDetails;
import com.example.flightTicket.dto.TicketResponseDto;
import com.example.flightTicket.exceptionHandling.ImproperCategoryException;
import com.example.flightTicket.exceptionHandling.InvalidCredentialsException;
import com.example.flightTicket.exceptionHandling.NoFlightsFoundException;
import com.example.flightTicket.exceptionHandling.NoSeatsAvailableException;
import com.example.flightTicket.exceptionHandling.PassengerDetailsRequiredException;
import com.example.flightTicket.exceptionHandling.TicketNotFoundException;
import com.example.flightTicket.model.CompositeId;
import com.example.flightTicket.model.Passenger;
import com.example.flightTicket.model.Ticket;

@Service
public class FlightTicketServiceImpl implements FlightTicketService {
	static int pId = 4000;
	static int tId = 5000;
	int ticketId = tId++;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	PassengerRepository passengerRepository;

	@Autowired
	TicketRepository ticketRepository;

	/* Book ticket after appropriate validations */
	@Override
	public ResponseEntity<ResponseContract> bookTicket(BookTicketRequestDto bookTicketRequestDto) {

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		String userUrl = "http://localhost:8083/users/login?userId=1001&password=s123";
		HttpEntity<String> userEntity = new HttpEntity<String>(headers);
		ResponseEntity<String> userResponse = restTemplate.exchange(userUrl, HttpMethod.GET, userEntity, String.class);

		/* Checking if flights exist with given source destination and date */
		String flightUrl = "http://localhost:8084/flights?source=" 
				+ bookTicketRequestDto.getSource() + "&destination="
				+ bookTicketRequestDto.getDestination() + "&date="
				+ bookTicketRequestDto.getDate();
		ResponseEntity<List<FlightResponseDto>> flightResponse;
		HttpEntity<List<FlightResponseDto>> flightEntity = new HttpEntity<List<FlightResponseDto>>(headers);
		try {
			flightResponse = restTemplate.exchange(flightUrl, HttpMethod.GET, flightEntity,
					new ParameterizedTypeReference<List<FlightResponseDto>>() {
					});

		} catch (Exception e) {
			throw new NoFlightsFoundException("No flight for your requirement");
		}

		/*
		 * Checking if entered flight id is matching with existing flight id with given
		 * source destination and time
		 */
		List<FlightResponseDto> filteredflightList = flightResponse.getBody().stream()
				.filter(f -> (int) f.getFlightId() == (int) bookTicketRequestDto.getFlightId())
				.collect(Collectors.toList());
		if (filteredflightList.isEmpty()) {
			throw new NoFlightsFoundException("FlightId not matching");
		}
		FlightResponseDto flightResponseDto = filteredflightList.get(0);

		/*
		 * Checking for availibility of seats and booking tickets only if seats are
		 * available.
		 */

		Boolean bool = false;
		String seatsUrl = "http://localhost:8084/flights/{flightId}/seats";
		HttpEntity<FlightSeatResponseDto> seatEntity = new HttpEntity<FlightSeatResponseDto>(headers);
		UriComponentsBuilder seatbuilder = UriComponentsBuilder.fromUriString(seatsUrl);
		ResponseEntity<FlightSeatResponseDto> seatResponse;
		seatResponse = restTemplate.exchange(seatbuilder.buildAndExpand(bookTicketRequestDto.getFlightId()).toUri(),
				HttpMethod.GET, seatEntity, FlightSeatResponseDto.class);

		switch (bookTicketRequestDto.getCategory()) {
		case "business":
			if (seatResponse.getBody().getBusinessSeats() - bookTicketRequestDto.getNumberOfTickets() >= 0)
				bool = true;
			break;
		case "economy":
			if (seatResponse.getBody().getEconomySeats() - bookTicketRequestDto.getNumberOfTickets() >= 0)
				bool = true;
			break;
		default:
			throw new ImproperCategoryException("Give proper category");
		}
		if (bool == false)
			throw new NoSeatsAvailableException("No seats available");

		if (bookTicketRequestDto.getPassenger().size() != bookTicketRequestDto.getNumberOfTickets()) {
			throw new PassengerDetailsRequiredException("Enter all passenger details");
		}

		/* Getting airport name to print in ticket */
		String airportUrl = "http://localhost:8084/airport?location=" + bookTicketRequestDto.getSource();
		HttpEntity<String> airportEntity = new HttpEntity<String>(headers);
		ResponseEntity<String> airportResponse = restTemplate.exchange(airportUrl, HttpMethod.GET, airportEntity,
				String.class);

		/* Setting ticket details. */
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Ticket ticket = modelMapper.map(bookTicketRequestDto, Ticket.class);
		ticket.setTicketId(ticketId);
		ticket.setAirportName(airportResponse.getBody());
		ticket.setArrivalTime(flightResponseDto.getArrivalTime());
		ticket.setDepartureTime(flightResponseDto.getDepartureTime());
		switch (bookTicketRequestDto.getCategory()) {
		case "business":
			ticket.setCost(bookTicketRequestDto.getNumberOfTickets() * flightResponseDto.getBusinessCost());
			break;
		case "economy":
			ticket.setCost(bookTicketRequestDto.getNumberOfTickets() * flightResponseDto.getEconomyCost());
			break;
		}
		ticketRepository.save(ticket);

		/* Setting passenger details */
		List<PassengerDetails> passengerList = bookTicketRequestDto.getPassenger();
		passengerList.stream().forEach(passenger -> setPassenger(passenger));

		/* Updating seat in database after ticket booking */
		String updateSeatUrl = "http://localhost:8084/flights/seats?flightId=" + bookTicketRequestDto.getFlightId()
				+ "&category=" + bookTicketRequestDto.getCategory() + "&numberOfTickets="
				+ bookTicketRequestDto.getNumberOfTickets();
		HttpEntity<Integer> updateSeatEntity = new HttpEntity<Integer>(headers);
		restTemplate.exchange(updateSeatUrl, HttpMethod.GET, updateSeatEntity, Integer.class);

		/* Setting ticket response contract */
		ResponseContract response = new ResponseContract("Ticket successfully booked", ticket.getTicketId());
		return new ResponseEntity<ResponseContract>(response, HttpStatus.OK);

	}

	public void setPassenger(PassengerDetails passengerDetail) {
		CompositeId compositeId = new CompositeId();
		compositeId.setTicketId(ticketId);
		compositeId.setPassengerId(pId++);
		Passenger passenger = new Passenger();
		passenger.setAge(passengerDetail.getAge());
		passenger.setName(passengerDetail.getName());
		passenger.setCompositeId(compositeId);
		passengerRepository.save(passenger);
	}

	/* Getting ticket details by passing ticketid */
	@Override
	public ResponseEntity<TicketResponseDto> getTicket(int ticketId) {

		Optional<Ticket> optionalTicket = ticketRepository.findById(ticketId);
		if (!optionalTicket.isPresent())
			throw new TicketNotFoundException("Improper ticket Id");
		Ticket ticket = optionalTicket.get();
		TicketResponseDto ticketResponseDto = modelMapper.map(ticket, TicketResponseDto.class);
		return new ResponseEntity<TicketResponseDto>(ticketResponseDto, HttpStatus.OK);

	}

	/* Cancel ticket */
	@Override
	public ResponseEntity<ResponseContract> cancelTicket(int ticketId) {
		Optional<Ticket> optionalTicket = ticketRepository.findById(ticketId);
		if (!optionalTicket.isPresent())
			throw new TicketNotFoundException("Improper ticket Id");
		Ticket ticket = optionalTicket.get();
		String updateSeatUrl = "http://localhost:8084/flights/cancel?flightId=" + ticket.getFlightId() + "&category="
				+ ticket.getCategory() + "&numberOfTickets=" + ticket.getNumberOfTickets();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Integer> updateSeatEntity = new HttpEntity<Integer>(headers);
		restTemplate.exchange(updateSeatUrl, HttpMethod.GET, updateSeatEntity, Integer.class);
		passengerRepository.deletePassengersById(ticketId);
		ticketRepository.deleteById(ticketId);
		ResponseContract response = new ResponseContract("Ticket successfully canceled", ticket.getTicketId());
		return new ResponseEntity<ResponseContract>(response, HttpStatus.OK);

	}

}
