package com.example.flightTicket.dto;

import java.sql.Time;

public class FlightResponseDto {
	  private Integer flightId;
	  private  String name;
	  private  Time departureTime;
	  private  Time arrivalTime;
	  private double economyCost;
	  private  double businessCost;
	  private String source;
	  private  String destination;
	  private int economySeats;
	  private int businessSeats;
	public Integer getFlightId() {
		return flightId;
	}
	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Time getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}
	public Time getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public double getEconomyCost() {
		return economyCost;
	}
	public void setEconomyCost(double economyCost) {
		this.economyCost = economyCost;
	}
	public double getBusinessCost() {
		return businessCost;
	}
	public void setBusinessCost(double businessCost) {
		this.businessCost = businessCost;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getEconomySeats() {
		return economySeats;
	}
	public void setEconomySeats(int economySeats) {
		this.economySeats = economySeats;
	}
	public int getBusinessSeats() {
		return businessSeats;
	}
	public void setBusinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}
	  
}
