package com.example.flightTicket.model;

import java.io.Serializable;

public class CompositeId  implements Serializable{
	private Integer passengerId;
	private Integer ticketId;
	public CompositeId() {}
	public CompositeId(Integer passengerId, Integer ticketId) {
		this.passengerId = passengerId;
		this.ticketId = ticketId;
	}
	public Integer getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(Integer passengerId) {
		this.passengerId = passengerId;
	}
	public Integer getTicketId() {
		return ticketId;
	}
	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}
	
	
}
