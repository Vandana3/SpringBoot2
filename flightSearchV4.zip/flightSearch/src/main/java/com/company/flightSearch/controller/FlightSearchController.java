package com.company.flightSearch.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.company.flightSearch.dto.FlightResponseDto;
import com.company.flightSearch.dto.FlightSeatResponseDto;
import com.company.flightSearch.service.FlightService;
import org.springframework.http.ResponseEntity;

import ch.qos.logback.classic.Logger;

@RestController
public class FlightSearchController {

	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(FlightSearchController.class);

	@Autowired
	FlightService flightService;

	@Autowired
	RestTemplate restTemplate;

	@GetMapping("/flights")
	public ResponseEntity<List<FlightResponseDto>> searchFlights(@RequestParam("source") String source,
			@RequestParam("destination") String destination, @RequestParam("date") Date date) {
		LOGGER.info("Inside flight search");
		return flightService.searchFlights(source, destination, date);
	}

	@GetMapping("/flights/name")
	public ResponseEntity<List<FlightResponseDto>> filterFlightsByName(@RequestParam("name") String name) {
		LOGGER.info("Inside filter flights by name");
		return flightService.filterFlightsByName(name);

	}

	@GetMapping("/flights/cost")
	public ResponseEntity<List<FlightResponseDto>> filterFlightsByCost(@RequestParam("cost") double cost) {
		LOGGER.info("Inside filter flights by cost");
		return flightService.filterFlightsByCost(cost);
	}

	@GetMapping("/flights/{flightId}/seats")
	public ResponseEntity<FlightSeatResponseDto>checkAvailability(@PathVariable("flightId") int flightId) {
		LOGGER.info("Checking for availibility of seats for given flight");
		return flightService.checkAvailability(flightId);
	}

	@GetMapping("/airport")
	public ResponseEntity<String> getAirportName(@RequestParam("location") String location) {
		LOGGER.info("Getting name of airport");
		return flightService.getAirportName(location);
	}

	@GetMapping("/flights/seats")
	public ResponseEntity<Integer>  updateSeatsAfterBooking(@RequestParam("flightId") int flightId, @RequestParam("category") String category,
			@RequestParam("numberOfTickets") int numberOfTickets) {
		LOGGER.info("Updation seats after ticket booking");
		return flightService.updateSeatsAfterBooking(flightId, category, numberOfTickets);
	}
	
	@GetMapping("/flights/cancel")
	public ResponseEntity<Integer>  updateSeatsAfterCancelling(@RequestParam("flightId") int flightId, @RequestParam("category") String category,
			@RequestParam("numberOfTickets") int numberOfTickets) {
		LOGGER.info("Updation seats after ticket cancelling");
		return flightService.updateSeatsAfterCancelling(flightId, category, numberOfTickets);
	}
}
